# nepse_app.py (Streamlit Dashboard)

import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
from fbprophet import Prophet
from datetime import datetime
import requests
from bs4 import BeautifulSoup

# Function to fetch NEPSE data
def fetch_nepse_data():
    url = "https://www.nepalstock.com.np/todays-price"
    headers = {"User-Agent": "Mozilla/5.0"}
    response = requests.get(url, headers=headers)
    soup = BeautifulSoup(response.content, "html.parser")
    
    table = soup.find("table")
    rows = table.find_all("tr")[1:]

    data = []
    for row in rows:
        cols = row.find_all("td")
        if len(cols) < 10:
            continue
        data.append({
            "Symbol": cols[1].text.strip(),
            "Close": float(cols[5].text.strip().replace(",", "")),
            "Volume": int(cols[8].text.strip().replace(",", "")),
            "Date": datetime.today().strftime("%Y-%m-%d")
        })

    df = pd.DataFrame(data)
    df.to_csv("nepse_data.csv", index=False)
    return df

# Forecast using Prophet
def forecast_stock(df, symbol, days):
    stock_df = df[df['Symbol'] == symbol].copy()
    today = datetime.today()
    dates = pd.date_range(end=today, periods=len(stock_df))
    stock_df['ds'] = dates
    stock_df['y'] = stock_df['Close']

    model = Prophet(daily_seasonality=True)
    model.fit(stock_df[['ds', 'y']])
    
    future = model.make_future_dataframe(periods=days)
    forecast = model.predict(future)
    return forecast

# Streamlit UI
st.title("NEPSE Stock Trend & Forecast App")

if st.button("Fetch Today's NEPSE Data"):
    data = fetch_nepse_data()
    st.success("Data Fetched Successfully!")
    st.write(data)

try:
    df = pd.read_csv("nepse_data.csv")
    symbols = df['Symbol'].unique().tolist()

    selected_symbol = st.selectbox("Select a Stock Symbol:", symbols)
    forecast_days = st.slider("Days to Forecast:", min_value=7, max_value=30, value=14)

    forecast = forecast_stock(df, selected_symbol, forecast_days)
    st.subheader(f"Forecast for {selected_symbol} (Next {forecast_days} Days)")

    fig, ax = plt.subplots()
    ax.plot(forecast['ds'], forecast['yhat'], label='Forecast')
    ax.fill_between(forecast['ds'], forecast['yhat_lower'], forecast['yhat_upper'], alpha=0.3)
    ax.set_title(f"Price Prediction for {selected_symbol}")
    ax.set_xlabel("Date")
    ax.set_ylabel("Predicted Price")
    ax.legend()
    st.pyplot(fig)

    st.dataframe(forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail(forecast_days))

except FileNotFoundError:
    st.warning("Please fetch the NEPSE data first by clicking the button above.")
